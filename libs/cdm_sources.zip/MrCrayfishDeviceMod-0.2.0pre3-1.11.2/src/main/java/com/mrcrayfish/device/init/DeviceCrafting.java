package com.mrcrayfish.device.init;

public class DeviceCrafting 
{
	public static void register()
	{
		
	}
}
